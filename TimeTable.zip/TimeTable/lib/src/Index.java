import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
class Index extends JFrame implements ActionListener{
    private JLabel label, l1,re,temp;
    private JPanel p1, p2, p3;
    private JTextField sear;
    private JButton se, cr, dr;
    
    Index() {
        setTitle("TimeTable Flash Screen");
        setSize(1024, 768);
        setLocation(300, 100);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        // Create Panels
        p1 = new JPanel();
        p2 = new JPanel();
        p3 = new JPanel();

        p1.setBounds(0, 0, 1024, 128);
        p2.setBounds(0, 130, 180, 620);
        p3.setBounds(190, 130, 824, 620);

        p1.setBackground(Color.BLACK);
        p2.setBackground(Color.DARK_GRAY);
        p3.setBackground(Color.WHITE);

        p1.setLayout(null);
        p2.setLayout(null);
        p3.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 20));

        add(p1);
        add(p2);
        add(p3);

        try {
            String imagePath = "C:/Users/khoba/OneDrive/Desktop/TimeMaster/logo.png";
            ImageIcon icon = new ImageIcon(makeRoundedImage(imagePath, 100));

           
            label = new JLabel(icon);
            label.setBounds(20, 15, 100, 100);

            
            l1 = new JLabel("TimeMaster", SwingConstants.CENTER);
            l1.setBounds(140, 40, 300, 40);
            l1.setForeground(Color.WHITE);
            l1.setFont(new Font("Algerian", Font.BOLD, 28));
            temp = new JLabel("                   ");

           
            sear = new JTextField(20);
            sear.setBounds(500, 30, 200, 30);
            sear.setFont(new Font("Arial", Font.PLAIN, 15));

           
            se = new JButton("Search");
            se.setBounds(720, 30, 100, 30);
            se.setFont(new Font("Arial", Font.BOLD, 12));
            se.setBackground(Color.WHITE);
            se.setForeground(Color.BLACK);

           
            String createImgPath = "C:/Users/khoba/OneDrive/Desktop/TimeMaster/create.png";
            String draftImgPath = "C:/Users/khoba/OneDrive/Desktop/TimeMaster/draft.png";
            String eventFilterIcon = "C:/Users/khoba/OneDrive/Desktop/TimeMaster/filter.png";

            ImageIcon createIcon = new ImageIcon(resizeImage(createImgPath, 30, 30));
            ImageIcon draftIcon = new ImageIcon(resizeImage(draftImgPath, 30, 30));
            ImageIcon filterIcon = new ImageIcon(resizeImage(eventFilterIcon, 30, 30));

            
            cr = new JButton("Create", createIcon);
            cr.setBounds(20, 50, 140, 50);
            cr.setFont(new Font("Arial", Font.BOLD, 16));
            cr.setBackground(Color.WHITE);
            cr.setForeground(Color.BLACK);
            cr.setHorizontalAlignment(SwingConstants.LEFT);

            dr = new JButton("Draft", draftIcon);
            dr.setBounds(20, 120, 140, 50);
            dr.setFont(new Font("Arial", Font.BOLD, 16));
            dr.setBackground(Color.WHITE);
            dr.setForeground(Color.BLACK);
            dr.setHorizontalAlignment(SwingConstants.LEFT);

            p2.add(cr);
            p2.add(dr);

           
            String[] buttonLabels = {"Year", "Semester", "Department", "Division"};
            for (String label : buttonLabels) {
                JButton btn = new JButton(label, filterIcon);
                btn.setFont(new Font("Arial", Font.BOLD, 14));
                btn.setBackground(Color.WHITE);
                btn.setForeground(Color.BLACK);
                btn.setBorder(BorderFactory.createLineBorder(Color.LIGHT_GRAY, 1));
                btn.setPreferredSize(new Dimension(160, 50));
                btn.setHorizontalAlignment(SwingConstants.LEFT);
                p3.add(btn);
            }

           
            re = new JLabel("Recent");
            p3.add(temp);
            p3.add(re);
            String[] eventImages = {
                "C:/Users/khoba/OneDrive/Desktop/TimeMaster/timetable.png",
                "C:/Users/khoba/OneDrive/Desktop/TimeMaster/timetable.png",
                "C:/Users/khoba/OneDrive/Desktop/TimeMaster/timetable.png"
            };
            for (String imgPath : eventImages) {
                ImageIcon eventIcon = new ImageIcon(resizeImage(imgPath, 200, 150));
                JLabel eventLabel = new JLabel(eventIcon);
                eventLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 1));
                p3.add(eventLabel);
            }

            p1.add(label);
            p1.add(l1);
            p1.add(sear);
            p1.add(se);

            cr.addActionListener(this);

        } catch (IOException e) {
            System.out.println("Error loading image: " + e.getMessage());
        }

        setVisible(true);
    }
    private Image makeRoundedImage(String path, int size) throws IOException {
        BufferedImage original = ImageIO.read(new File(path));
        BufferedImage rounded = new BufferedImage(size, size, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2 = rounded.createGraphics();

        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setClip(new java.awt.geom.Ellipse2D.Float(0, 0, size, size));

        g2.drawImage(original, 0, 0, size, size, null);
        g2.dispose();

        return rounded;
    }
    private Image resizeImage(String path, int width, int height) throws IOException {
        BufferedImage original = ImageIO.read(new File(path));
        return original.getScaledInstance(width, height, Image.SCALE_SMOOTH);
    }
    public void actionPerformed(ActionEvent ae) {
        new Time_table();
        setVisible(false);
    }
    public static void main(String[] args) {
        new Index();
    }
}